const chalkani = require('chalk-animation')
chalk.rainbow('loading......')